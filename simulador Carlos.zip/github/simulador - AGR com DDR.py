	#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
implementação da estratégia MSU
"""

import SimPy
from SimPy import *
from SimPy.Simulation import *
from random import *
from simulador import *
from config import *
import networkx as nx
import math
import time
from datetime import datetime

from random import randrange
import numpy as np

from estatistica import Media, CalculaMediaDesvio

topology = nx.read_weighted_edgelist(TOPOLOGY, nodetype=int)
topologyAux = nx.read_weighted_edgelist(TOPOLOGY, nodetype=int)                  # utilizado apenas para a estratégiaMu, ajustar com a já existente.

# Variaveis globais
#bloqueado = 0
#nao_bloqueado = 0
no_regenerador = 0
#n_requisicao = 0
validar_caminho = False         # verifica se existe um caminho valido origem-destino para uma requisicao
validar_caminhoBackup = False   # verifica se existe um caminho backup valido origem-destino para um requisicao
vetorReg = []
num_slots = 0
TotalVer = 0
vetorVer = []
vetorPath = []
vetorPathAux = []
#subVer= []
pathSimulation = []
no1 = 0
no2= 0
vetorMu = []
pathAux = []
slots_global = 0


class Desalocate(Process):
	def __init__(self):
		SimPy.Simulation.Process.__init__(self)

	# Libera espectro apos o holding time    
	def Run(self,count,s_path,holding_time, num_slots):
		global topology
		simulador = Simulador()
		desalocate = Desalocate()
		#print "caminho run: " +str(s_path)
		
		self.holding_time = holding_time 
		yield hold, self, self.holding_time

		## Procurar indices.
		inicio = 0
		fim = 0
		flag = 0
		# print "caminho run2: " +str(s_path)             #caminho de fato que será desalocado.
		desalocate.DesalocateVer(s_path)
		for slot in range(0,len(topology[s_path[0]][s_path[1]]['capacity'])):
			if topology[s_path[0]][s_path[1]]['capacity'][slot] == count:
				if flag == 0:
					inicio = slot
					flag += 1
				fim = slot
		for i in range(0, (len(s_path)-1)):
			for slot in range(inicio,fim+1):
				topology[s_path[i]][s_path[i+1]]['capacity'][slot] = 0
				topology[s_path[i]][s_path[i+1]]['class_type'][slot] = 0
				#print "Desalocate: " +str(s_path[i])
			topology[s_path[i]][s_path[i+1]]['capacity'][fim+1] = 0
			topology[s_path[i]][s_path[i+1]]['capacity'][fim+1] = 0

		

	def DesalocateVer(self, s_path):
		global topology
		global vetorVer
		
		simulador = Simulador()
		#Simulador.VerSimultaneoAux = Simulador.VerSimultaneoAux - 
		
		#global vetorPath
		for i in vetorVer:
			if (i[0] == s_path):
				#print "CAMINHO DESALOCADO: " +str(i[0]) +str(i[1])
				for j in range(0, (len(i[1]))):
					#return i[2]                                        
					#print "NO DESALOCADO...: " + str(i[1][j]) + " SLOT...: " +str(i[2])
					#print "NO DESALOCADO...: " + str(i[1][j][0]) + " SLOT...: " +str(i[1][j][1])
					#simulador.Add_regenerador(i[1][j][0], int(topology.node[int(i[1][j][0])]['regenerador']) + i[1][j][1])  #Libera o subVER
					
					simulador.Add_regenerador(i[1][j][0], float(topology.node[float(i[1][j][0])]['regenerador']) + i[1][j][1])  #Libera o subVER
					#print "NO DESALOCADO...: " + str(i[1][j]) + " SLOT...: " +str(topology.node[int(i[1][j])]['regenerador']) + " Slots Atual"
					Simulador.VerSimultaneoAux = Simulador.VerSimultaneoAux - float(i[1][j][1])
				i.remove(s_path)
				#print vetorVer
				vetorVer.remove(i)
				#print vetorVer
				
class Simulador(Process):
	#global validar_caminho
	NumReqBlocked = 0
	NumReqBlocked2= 0
	NumReqBlockedAxu = 0
	NumReqAccept = 0
	VerSimultaneo = 0                       # variável utilizada para detectar a quantidade de VER utilizada simultanemente durante as simulações
	VerSimultaneoAux = 0
	#cont_req = 0
	NumReq = 0
	ListReg = 0
	Ver = 0
	total_slotsInicial = 0
	total_slotsFinal = 0

	
	
	def __init__(self):
		SimPy.Simulation.Process.__init__(self)
		global topology
		for u, v in topology.edges_iter():
			topology[u][v]['capacity'] = [0] * SLOTS
			topology[u][v]['class_type'] = [0] * SLOTS
		self.nodes = topology.nodes()
		self.edges = topology.edges()
		self.random = Random()

	def Run(self, rate):
		global topology
		global n_requisicao
		global validar_caminho
		
		edges = topology.number_of_edges()
		r = rate * topology.number_of_nodes()  
		#Simulador.NumReqBlocked = 0 ## n. requisicoes bloqueadas
		#Simulador.cont_req = 0
		Simulador.holding_time = 0
		cont = 0
		Simulador.NumReqBlocked2 = 0
		Simulador.VerSimultaneoAux = 0
		Simulador.VerSimultaneo = 0
		Simulador.total_slotsInicial = 0
		Simulador.total_slotsFinal = 0
		#Simulador.NumReq = 0

		req_pendentes = []
		
		for count in xrange(1, NUM_OF_REQUESTS + 1):
			yield hold, self, self.random.expovariate(r) 
			src, dst = self.random.sample(self.nodes, 2)            # requisicoes de origem - destino
			dmd = self.random.choice(REQUESTS_DEMANDS)              # recebe valores aleatorios de [10,20,40,80,160,200,400]
						
			#NUMERO DE VER CONFORME SUPER CHANNEL
			qtdVer = (float(dmd)/100)

			data = self.random.choice(DATA)                         #recebe valores aleatorios de [50,150,200,250]
			s_path = self.ConsultaPath(src, dst)
			dld = self.random.choice(DEADLINE_DRIVEN)
			tmp = datetime.now()
			adv = self.random.choice(ADVANCED)                      #recebe aleatoriamente se e tolerante ao atraso [2] ou nao tolerante [1]

			#Armazenando toda requisicao juntamente com seu Deadline
			req_pendentes.append([s_path, data, dmd, qtdVer, tmp, dld, True, adv])
			Simulador.NumReq += 1
			
			for i in xrange(1, len(req_pendentes)):
				now = datetime.now()                    #Hora atual
				calc = now - req_pendentes[i][4]        #Calculando a hora atual - a hora de entrada da requisicao
				sec = int(calc.total_seconds())         #Armazenando apenas os segundos

				#if (ADVANCED == 1):
				if (req_pendentes[i][7] == 1):
					#print "entrou NAO TOLERANTE"
					if ((sec >= req_pendentes[i][5]) and (req_pendentes[i][6] == True)):
						#print "ENTROU 2..: " +str(req_pendentes[i][0])
						s_path_aux = req_pendentes[i][0]
						data_aux = req_pendentes[i][1]
						dmd_aux = req_pendentes[i][2]
						qtdVer_aux = req_pendentes[i][3]
						distance = int(Simulador.Distance(self, s_path_aux))
						num_slots = int(math.ceil(Simulador.Modulation(self, distance, dmd_aux)))
						#print "dados..: " +str(s_path_aux) +", "+str(num_slots) +", "+str(dmd_aux) +", "+str(qtdVer_aux)
						validar = self.VerificarVer(topology, s_path_aux, num_slots, dmd_aux, qtdVer_aux)

						if (validar == True):
							#print "entrou"
							#VERIFICA se possui spectro disponivel no caminho e se atende os parametros de restricao
							Simulador.check_path = Simulador.PathIsAble(self,num_slots,s_path_aux)                              
							if (Simulador.check_path[0] == False):
								'REQUISIÇÃO BLOQUEADA'
								Simulador.NumReqBlocked += 1
								Simulador.NumReqBlocked2 += 1
								Simulador.NumReqBlockedAux += 1
								Simulador.NumReqBlockedRecurso += 1
							else:
								Simulador.NumReqAccept += 1
								Simulador.FirstFit(self, count,Simulador.check_path[1],Simulador.check_path[2],s_path_aux)
								Simulador.holding_time = Simulador.CalculaTempoTrans(self,dmd_aux,data_aux)
								#Libera espectro apos o holding time
								desalocate = Desalocate()
								SimPy.Simulation.activate(desalocate, desalocate.Run(count,s_path_aux,Simulador.holding_time, num_slots))
						else:
							Simulador.NumReqBlocked += 1
							Simulador.NumReqBlocked2 += 1
							Simulador.NumReqBlockedAux += 1
							Simulador.NumReqBlockedRecurso += 1
						
						req_pendentes[i][6] = False
						#req_pendentes.remove([s_path, data, dmd, qtdVer, tmp, dld, True, adv])
						#i.remove(s_path_aux)
						#print vetorVer
						#req_pendentes.remove(i)
				#elif (ADVANCED == 2):
				if (req_pendentes[i][7] == 2):
					#print "entrou TOLERANTE"
					if ((req_pendentes[i][6] == True)):
						#print "ENTROU 2..: " +str(req_pendentes[i][0])
						s_path_aux = req_pendentes[i][0]
						data_aux = req_pendentes[i][1]
						dmd_aux = req_pendentes[i][2]
						qtdVer_aux = req_pendentes[i][3]
						distance = int(Simulador.Distance(self, s_path_aux))
						num_slots = int(math.ceil(Simulador.Modulation(self, distance, dmd_aux)))
						#print "dados..: " +str(s_path_aux) +", "+str(num_slots) +", "+str(dmd_aux) +", "+str(qtdVer_aux)
						validar = self.VerificarVer(topology, s_path_aux, num_slots, dmd_aux, qtdVer_aux)

						if (validar == True):
							#print "entrou"
							#VERIFICA se possui spectro disponivel no caminho e se atende os parametros de restricao
							Simulador.check_path = Simulador.PathIsAble(self,num_slots,s_path_aux)                              
							if (Simulador.check_path[0] == False):
								'REQUISIÇÃO BLOQUEADA'
								Simulador.NumReqBlocked += 1
								Simulador.NumReqBlocked2 += 1
								Simulador.NumReqBlockedAux += 1
								Simulador.NumReqBlockedRecurso += 1
								req_pendentes[i][6] = False
							else:
								Simulador.NumReqAccept += 1
								Simulador.FirstFit(self, count,Simulador.check_path[1],Simulador.check_path[2],s_path_aux)
								Simulador.holding_time = Simulador.CalculaTempoTrans(self,dmd_aux,data_aux)
								#Libera espectro apos o holding time
								desalocate = Desalocate()
								SimPy.Simulation.activate(desalocate, desalocate.Run(count,s_path_aux,Simulador.holding_time, num_slots))
								req_pendentes[i][6] = False
						elif (sec >= req_pendentes[i][5]):
							Simulador.NumReqBlocked += 1
							Simulador.NumReqBlocked2 += 1
							Simulador.NumReqBlockedAux += 1
							Simulador.NumReqBlockedTempo += 1
							req_pendentes[i][6] = False
						
		for i in xrange(1, len(req_pendentes)):
			if (req_pendentes[i][6] == True):
				s_path_aux = req_pendentes[i][0]
				data_aux = req_pendentes[i][1]
				dmd_aux = req_pendentes[i][2]
				qtdVer_aux = req_pendentes[i][3]
				distance = int(Simulador.Distance(self, s_path_aux))
				num_slots = int(math.ceil(Simulador.Modulation(self, distance, dmd_aux)))
				validar = self.VerificarVer(topology, s_path_aux, num_slots, dmd_aux, qtdVer_aux)

				if (validar == True):
					#VERIFICA se possui spectro disponivel no caminho e se atende os parametros de restricao
					Simulador.check_path = Simulador.PathIsAble(self,num_slots,s_path_aux)                              
					if (Simulador.check_path[0] == False):
						'REQUISIÇÃO BLOQUEADA'
						Simulador.NumReqBlocked += 1
						Simulador.NumReqBlocked2 += 1
						Simulador.NumReqBlockedAux += 1
						Simulador.NumReqBlockedRecurso += 1
					else:
						Simulador.NumReqAccept += 1
						Simulador.FirstFit(self, count,Simulador.check_path[1],Simulador.check_path[2],s_path_aux)
						Simulador.holding_time = Simulador.CalculaTempoTrans(self,dmd_aux,data_aux)
						#Libera espectro apos o holding time
						desalocate = Desalocate()
						SimPy.Simulation.activate(desalocate, desalocate.Run(count,s_path_aux,Simulador.holding_time, num_slots))
				else:
					Simulador.NumReqBlocked += 1
					Simulador.NumReqBlocked2 += 1
					Simulador.NumReqBlockedAux += 1
					Simulador.NumReqBlockedTempo += 1
						
				req_pendentes[i][6] = False
			
		#print "total requisicoes.: " +str(Simulador.NumReq)
		
	# Adicionando regenerador OEO ao vertice
	def Add_regenerador(self, a, r):
		topology.add_nodes_from([a],regenerador=r)
		regenerador=nx.get_node_attributes(topology ,'regenerador')
		return regenerador[a]

	def Add_regeneradorAux(self, a, r):
		topologyAux.add_nodes_from([a],regenerador=r)
		regenerador=nx.get_node_attributes(topologyAux ,'regenerador')
		return regenerador[a]

	# Consultar um caminho
	def ConsultaPath(self, inicio, fim):
		global vetorPath
		
		for i in vetorPath:
			if (i[0] == inicio) and (i[1] == fim):
				return i[2]

	# Consultar um caminho backup
	def ConsultaPathBackup(self, inicio, fim):
		global vetorPath
		
		for i in vetorPathBackup:
			if (i[0] == inicio) and (i[1] == fim):
				return i[2]
	
	# Seleciona o menor melhor caminho dentre o conjunto de caminhos validos
	def CaminhoValido(self, graph, inicio, fim):
		global topology
		global validar_caminho

		caminhos = list(self.dfs(inicio, fim))
		i = 0
		j = len(caminhos)
		fim = False
		validar_caminho = False
		while (i < j) or (fim == True):
			if (self.Caminho(topology, caminhos[i]) == True):
				validar_caminho = True
				fim = True
				return caminhos[i]                              
				#cont+=1
			elif (i >= j):
				return caminhos[i]

			i += 1
			
	# Seleciona um segundo caminho ou caminho de backup dentre o conjunto de caminhos validos
	def CaminhoBackup(self, graph, inicio, fim, path):
		global topology
		global validar_caminhoBackup

		caminhos = list(self.dfs(inicio, fim))
		i = 0
		j = len(caminhos)
		fim = False
		validar_caminhoBackup = False
		while (i < j) or (fim == True):
			if ((self.Caminho(topology, caminhos[i]) == True) and (caminhos[i] != path)):
				k = 0
				vetorPath.sort()
				for k in range(len(vetorPath)):
				#for k in vetorPath:
					#print "inicio: " +str(vetorPath[k][0])
					#print "fim   : " +str(vetorPath[k][1])
					#print "path  : " +str(vetorPath[k][2])
					#if ((vetorPath[k][0] == inicio) and (vetorPath[k][1] == fim) and (vetorPath[k][2] == path)):
					if (vetorPath[k][2] == path):
						#print "entrou False"
						validar_caminhoBackup = False
					else:
						#print "entrou verdadeiro"
						validar_caminhoBackup = True
						fim = True
						return caminhos[i]
			elif (i >= j):
				return caminhos[i]

			i += 1
	
	# Verificar todos os caminhos possiveis
	def dfs(self, inicio, fim):
		global topology
		pilha = [(inicio, [inicio])]
		while pilha:
			vertice, caminho = pilha.pop()
			for proximo in set(topology[vertice]) - set(caminho):
				if proximo == fim:
					yield caminho + [proximo]
				else:
					pilha.append((proximo, caminho + [proximo]))                                    

	def CaminhoMu(self, graph, path):
		global topology 
		#global vetorMu

		soma  = 0       
		salto = 0       
		block = 1
		for i in range(0, (len(path)-1)):               
			soma = soma + topology[path[i]][path[i+1]]['weight']            #recebe peso da aresta entre i e i+1
			salto= salto + 1                                                #incrementa o salto             
			if (soma > PARAMETRO_DISTANCIA) or (salto > PARAMETRO_SALTO):
				# print path[i]
				vetorMu.append(path[i])
				soma = 0
				salto= 0
		
	# Validacao do caminho. Retorna se um certo caminho (o - d) e bloqueado ou nao
	def Caminho(self, graph, path): 
		global bloqueado
		global n_requisicao
		global nao_bloqueado
		global topology 
		global parametro_dist
		global parametro_salto
		global no_regenerador

		soma  = 0       
		salto = 0       
		block = 1
		#n_requisicao = n_requisicao + 1
		for i in range(0, (len(path)-1)):               
			soma = soma + topology[path[i]][path[i+1]]['weight']    #recebe peso da aresta entre i e i+1
			salto= salto + 1                                                #incrementa o salto
		
			if (soma > PARAMETRO_DISTANCIA) or (salto > PARAMETRO_SALTO):
				return False
			try:
				#if (topology.node[path[i+1]]['regenerador']) != 0:        #verifica se existe regenerador no proximo vertice
				if (topology.node[path[i+1]]['regenerador']) > 0:
					#Simulador.Ver += 1
					soma = 0                                                #se existe, zera os parametros e continua ate atingir o destino ou outro ponto de restauracao
					salto= 0
			except Exception:
				""
		return True
			

	# verifica se existe subVer disponível para regenerar o sinal
	def VerificarVer(self, graph, path, num_slots, dmd, qtdVer): 
		global topology
		simulador = Simulador()
		soma  = 0       
		salto = 0       
		block = 1
		subVer= []
		validar_caminho = True
		pathAux = path[:]
		slotsEconomizado = 0

		#if (qtdVer < 1):
		#       qtdVer = 1
		#elif ((dmd % 100) > 0):
		#       qtdVer += 1                                
		
		#i = 0

		t = len(path)

		if (AGRUPAMENTO == 'NAO'):
			if (qtdVer < 1):
				qtdVer = 1
			elif ((dmd % 100) > 0):
				qtdVer = (math.trunc(qtdVer)+1)
				#qtdVer = (math.ceil(qtdVer))+1                              
			#print "nnnnnn = " +str(float(qtdVer))                                                                                          
		
		#while (i < (len(path)-1)):
		for i in range(len(path)-1):
			if validar_caminho == True:
				try:
					if not (topology.node[path[i]]):                                              # verifica se uma lista esta vazia
						pathAux.remove(pathAux[0])
					elif ((topology.node[path[i]]['regenerador']) >= 0) and (i > 0): 
						if (TYPE_REG == '4R'):                          #se for regenerador 4R verifica se do ponto VER até o final possui uma melhor condição melhor de slot de frequência
							if (i == 0):
								pathAux.remove(pathAux[0])
								
							distanceAux = int(Simulador.Distance(self, pathAux))
							num_slotsAux = int(math.ceil(Simulador.Modulation(self, distanceAux, dmd)))
							#print "Slot atual  : " +str(num_slots)
							#print "Slot novo   : " +str(num_slotsAux)
							#print "Economizado : " +str(num_slots-num_slotsAux)
							Simulador.total_slotsInicial = Simulador.total_slotsInicial + num_slots
							slotsEconomizado = num_slots - num_slotsAux
							#print "Economizado : " +str(slotsEconomizado)
							if (num_slots > num_slotsAux):          #se for melhor converte o slot atual
								num_slots = num_slotsAux
								#print "entrou"
								Simulador.total_slotsFinal = Simulador.total_slotsFinal + slotsEconomizado
						#n = int(topology.node[path[i]]['regenerador'])- num_slots
						n2 = float(topology.node[path[i]]['regenerador'])
						n = n2 - qtdVer

						if (n >= 0):                                    # se a quantidade de regeneradores do nós for maior ou igual a zero
							subVer.append([(path[i]),(qtdVer)])
							#Simulador.Ver += 1
							soma = 0                                                #se existe, zera os parametros e continua ate atingir o destino ou outro ponto de restauracao
							salto= 0                                        
							self.Add_regenerador(path[i], n)
							#if (len(subVer) == 1):
							#       #print "ENTROU PRIMEIRO DA LISTA"
							#       Simulador.Ver += 1
							#       Simulador.VerSimultaneoAux += qtdVer 
							#print "Nooo..: " +str(path[i]) + " N2..: " +str(float(n2)) + " N..: " +str(float(n))
							if ((math.trunc(n2)) > (math.trunc(n))):
								#print "ENTROU .. "
								#print "Nooo..: " +str(path[i]) + " N2..: " +str(math.trunc(n2)) + " N..: " +str(math.trunc(n))
								#print "_______________________________"
								Simulador.Ver += 1
								Simulador.VerSimultaneoAux += qtdVer
							#else:
							#       print "-== NÃO ENTROU ==-"
 
							#Simulador.VerSimultaneoAux += qtdVer                    #armazena a quantidade de VER para avaliação da quantidade máxima futura
							if (Simulador.VerSimultaneoAux > Simulador.VerSimultaneo):
								#print "entrou"
								#print "Ver..: " +str(Simulador.VerSimultaneo) + " Ver Aux..: " +str(Simulador.VerSimultaneoAux)
								Simulador.VerSimultaneo = Simulador.VerSimultaneoAux
								#print "Ver..: " +str(Simulador.VerSimultaneo)

							"""n = len(vetorReg)
							for i in range(n):
								print "Ver: " +str(vetorReg[i]) + " " +str(topology.node[int(vetorReg[i])]['regenerador'])
							print "________________________"
							"""
						elif (n < 0):                                   # se um nó não possuir VER suficiente, devolve os VER dos nós anteriores e bloqueia a requisição
							#if (ROUTE_AUX == 'SIM'):
							#       s_path(self.CaminhoValido(topology, path[i], path[len(path)])
							#       print "Caminho bloqueado..: " +str(path)
							#       print "NO 1: " +str(path[i])
							#       print "Tamanho: " +str(t)
							#       print "NO 2: " +str(path[len(path)-1])
								
							if (AGRUPAMENTO == 'NAO'):
								validar_caminho = False                                                 
								j = 0
								for j in range(len(subVer)):                       #se algum nó nao tiver Ver suficiente, retornar os subVer dos caminhos anteriores utilizados
									m = float(topology.node[subVer[j][0]]['regenerador'])+ (subVer[j][1])
									self.Add_regenerador(subVer[j][0], m)
									#print "-== BLOQUEADO ==-"
									#print "Ver Aux..: " +str(Simulador.VerSimultaneoAux)
									Simulador.VerSimultaneoAux = Simulador.VerSimultaneoAux - qtdVer
									#print "Ver Aux..: " +str(Simulador.VerSimultaneoAux)
							elif (AGRUPAMENTO == 'SIM'):
								validar_caminho = False                                                 
								j = 0
								for j in range(len(subVer)):                       #se algum nó nao tiver Ver suficiente, retornar os subVer dos caminhos anteriores utilizados
									m = float(topology.node[subVer[j][0]]['regenerador'])+ (subVer[j][1])
									self.Add_regenerador(subVer[j][0], m)
									#print "-== BLOQUEADO ==-"
									#print "Ver Aux..: " +str(Simulador.VerSimultaneoAux)
									Simulador.VerSimultaneoAux = Simulador.VerSimultaneoAux - qtdVer
									#print "Ver Aux..: " +str(Simulador.VerSimultaneoAux)
									
							
						pathAux.remove(pathAux[0])
					else:
						pathAux.remove(pathAux[0])
				except Exception:
					""
			i += 1
		if validar_caminho == True:
			vetorVer.append([(path),(subVer)])                      # armazena o caminho e o vetor subVer com todos os nós e subcanais regenerados
			return True
		else:
			return False

				
	# Alocação de subVER uniforme para todos os VER
	def AlocarVer(self):
		global topology
		simulador = Simulador()
		d = VER/len(vetorReg)
		n = len(vetorReg)
		for i in range(n):
			self.Add_regenerador(vetorReg[i], d)
		#simulador.'(7, 2)

	def AlocarVerMsu(self, soma, vetorAux):
		global topology
		simulador = Simulador()
		#print vetorAux
		#d = VER/len(vetorReg)
		n = len(vetorReg)
		for i in range(n):
			#self.Add_regenerador(vetorReg[i], d)
			self.Add_regenerador(vetorReg[i], (int(vetorAux[i][1])*VER)/soma)

	# Regenerar sinal 
	def RegeneratePath(self, ver, num_slots):
		global topology
		
		n = len(vetorReg)
		for i in range(n):
			if vetorReg[i] == ver:
				self.Add_regenerador(ver, int(topology.node[int(ver)]['regenerador'])- num_slots)
			else:
				"NÃO ENTROU"

	def EstrategiaLndf(self):
		global topology
		simulador = Simulador()
		
		deg = nx.degree(topology)
		lista2 = deg.values()
		lista3 = sorted(deg)
		vet = topology.degree(weight='weight')
		lista4 = vet.values()
		lista5 = sorted(vet)

		n = topology.number_of_nodes()
		wow = np.zeros((n,3))

		for i in range(n):      
			wow[i] = np.array([lista5[i],lista2[i], lista4[i]])     

		dt = [('col1', wow.dtype),('col2', wow.dtype),('col3', wow.dtype)]
		aux = wow.ravel().view(dt)
		aux.sort(order=['col2','col3'])

		i = 0
		fim = False
		
		for i in range(n):
			if (fim == False):                              
				self.Add_regenerador(int(aux[::-1][i][0]), 1)                           
				vetorReg.append(int(aux[::-1][i][0]))
				if (self.VerificarConectividade() == True):
					fim = True
				else:
					i += 1
		simulador.AlocarVer()

	# Posicionamento de Regeneradores estratégia NDF
	def EstrategiaNdf(self):
		global topology
		simulador = Simulador()
		
		deg = nx.degree(topology)
		lista2 = deg.values()
		lista3 = sorted(deg)            
		n = topology.number_of_nodes()
		wow = np.zeros((n,2))

		for i in range(n):      
			wow[i] = np.array([lista3[i],lista2[i]])        

		dt = [('col1', wow.dtype),('col2', wow.dtype)]
		aux = wow.ravel().view(dt)
		aux.sort(order=['col2','col1'])

		i = 0
		fim = False
		for i in range(n):
			if (fim == False):
				self.Add_regenerador(int(aux[::-1][i][0]), 1)
				vetorReg.append(int(aux[::-1][i][0]))
				#print str((aux[::-1][i][0]))
				if (self.VerificarConectividade() == True):
					fim = True
				else:
					i += 1
		simulador.AlocarVer()

	# Posicionamento de Regeneradores estratégia MU e MSU
	def EstrategiaMuMsu(self):
		global topology
		global topologyAux
		vetorAux = []
		
		simulador = Simulador()
		n = topology.number_of_nodes()
		wow = np.zeros((n,2))

		for i in range(topologyAux.number_of_nodes()):      
			self.Add_regeneradorAux(i, 1)   

		for j in xrange(1, NUM_OF_REQUESTS + 1):
			src, dst = self.random.sample(self.nodes, 2)            # requisicoes de origem - destino
			length, s_path = nx.bidirectional_dijkstra(topologyAux,src,dst)                 
			self.CaminhoMu(topologyAux, s_path)
		for k in range(n):      
			wow[k] = np.array([k,vetorMu.count(k)])        

		dt = [('col1', wow.dtype),('col2', wow.dtype)]
		aux = wow.ravel().view(dt)
		aux.sort(order=['col2','col1'])

		i = 0
		soma = 0
		fim = False
		for i in range(n):
			if (fim == False):
				#print str((aux[::-1][i][0]))
				self.Add_regenerador(int(aux[::-1][i][0]), 1)
				vetorReg.append(int(aux[::-1][i][0]))
				#print str((aux[::-1][i][0]))
				vetorAux.append(aux[::-1][i])
				# print (aux[::-1][i])
				soma += (int(aux[::-1][i][1]))
				if (self.VerificarConectividade() == True):
					fim = True
				else:
					i += 1

		if (ESTRATEGIA_POSICIONAMENTO == 'MU'):
			simulador.AlocarVer()
		elif (ESTRATEGIA_POSICIONAMENTO == 'MSU'):
			simulador.AlocarVerMsu(soma, vetorAux)
		
	# Verifica a conectividade da rede a cada nó OEO posicionado
	def VerificarConectividade(self):
		global topology
		global validar_caminho
		
		n = topology.number_of_nodes()          
		for no1 in range(n):
			for no2 in range(n):
				if no1 == no2:
					no2 += 1
				else:
					s_path = self.CaminhoValido(topology, no1, no2)                                 
					if (validar_caminho == True):
						'Caminho encontrado'
						vetorPath.append([(no1), (no2), (s_path)])
						no2 += 1
						""
					else:
						'Caminho não encontrado'
						return False
			no1 += 1
		return True

	# Posicionamento de Regeneradores estratégia HNF
	def Hnf(self, a):
		simulador = Simulador()
		aux = []

		aux.append(5)
		aux.append(8)
		aux.append(13)
		aux.append(11)
		aux.append(7)

		i = 0
		fim = False
		for i in range(len(aux)):
			if (fim == False):
				self.Add_regenerador(int(aux[i]), 1)
				vetorReg.append(int(aux[i]))
				#print str((aux[::-1][i][0]))
				if (self.VerificarConectividade() == True):
					fim = True
				else:
					i += 1
			
		simulador.AlocarVer()
			
	# Posicionamento de Regeneradores
	def Lhnf(self, a):
		if a == 1:
			# NFSnet estrategia L-HNF grau logico ABILENE
			self.Add_regenerador(1, 1)
			self.Add_regenerador(8, 1)
			self.Add_regenerador(7, 1)
			self.Add_regenerador(2, 1)
			self.Add_regenerador(9, 1)
			self.Add_regenerador(0, 1)
			self.Add_regenerador(3, 1)
			#self.Add_regenerador(10)
			#self.Add_regenerador(5)
			#self.Add_regenerador(6)
			#self.Add_regenerador(4)

	# Calcula a distancia do caminho de acordo com os pesos das arestas               
	def Distance(self, path):
		global topology 
		soma = 0
		#print "Caminho Distance...: " +str(path)
		for i in range(0, (len(path)-1)):
			soma += topology[path[i]][path[i+1]]['weight']
		return (soma)

	# Calcula o formato de modulacao de acordo com a distancia do caminho    
	def Modulation(self, dist, demand):
		if dist <= 500:
			return (float(demand) / float(4 * SLOT_SIZE))
		elif 500 < dist <= 1000:
			return (float(demand) / float(3 * SLOT_SIZE))
		elif 1000 < dist <= 2000:
			return (float(demand) / float(2 * SLOT_SIZE)) 
		else:
			return (float(demand) / float(1 * SLOT_SIZE))

	def FirstFit(self,count,i,j,path):
		global topology
		inicio = i 
		fim =j
		for i in range(0,len(path)-1):
			for slot in range(inicio,fim):
				#print slot
				topology[path[i]][path[i+1]]['capacity'][slot] = count
			topology[path[i]][path[i+1]]['capacity'][fim] = 'GB'

	# Calcula o tempo de transmissao de uma requisicao
	def CalculaTempoTrans(self,dmd,data):
		tempo = 0.0
		tempo = data/float(dmd)
		tempo2 = round(tempo, 1) 
		return  tempo2

	# Verifica se o caminho escolhido possui espectro disponivel para a demanda requisitada
	def PathIsAble(self, nslots,path):
		global topology
		cont = 0
		t = 0
		 
		#print "Slots... : " +str(nslots) + " " +str((len(topology[path[0]][path[1]]['capacity']))-nslots)
		for slot in range (0,len(topology[path[0]][path[1]]['capacity'])):
			if topology[path[0]][path[1]]['capacity'][slot] == 0:
				k = 0
				for ind in range(0,len(path)-1):
					if topology[path[ind]][path[ind+1]]['capacity'][slot] == 0:
						k += 1
				if k == len(path)-1:
					cont += 1
					if cont == 1:
						i = slot
					if cont > nslots:
						j = slot
						#print "Slots... : " +str(len(topology[path[0]][path[1]]['capacity']))
						return [True,i,j]
					if slot == len(topology[path[0]][path[1]]['capacity'])-1:
							return [False,0,0]
				else:
					cont = 0
					if slot == len(topology[path[0]][path[1]]['capacity'])-1:
						return [False,0,0]
			else:
				cont = 0
				if slot == len(topology[path[0]][path[1]]['capacity'])-1:
					return [False,0,0]

	# Seleciona o melhor menor caminho dentre o conjunto de menores caminhos
	def SelectShortestPath(self, paths, dmd):
		global topology
		distance = []
		n_slots = float(dmd) / float(SLOT_SIZE)
		index = 0
		for path in paths:
			if Simulador.PathIsAble(self, n_slots, path) == False:
				paths.remove(path)
		if len(paths) == 0:
			return paths

		else:
			for p in paths:
				distance.append(int(math.ceil(Simulador.Distance(self, p)))) 
			menor = min(distance)
			for pos, num in enumerate(distance):
				if num == menor:
					indice = pos
				return paths[index]
			

def main(args):
	global TotalVer
	global topology
	if SIMULATION == 1:
		arquivo1 = open('bloqueio'+'.dat', 'w')
		simulador = Simulador()
		
		# Estrategia de posicionamento
		if ESTRATEGIA_POSICIONAMENTO == 'NDF':
			#simulador.Ndf(QTD_REG)
			simulador.EstrategiaNdf()
		elif ESTRATEGIA_POSICIONAMENTO == 'LNDF':
			#simulador.Lndf(QTD_REG)
			simulador.EstrategiaLndf()
		elif ESTRATEGIA_POSICIONAMENTO == 'HNF':
			simulador.Hnf(1)
		elif ESTRATEGIA_POSICIONAMENTO == 'LHNF':
			simulador.Lhnf(1)                        
		elif ESTRATEGIA_POSICIONAMENTO == 'MU':
			simulador.EstrategiaMuMsu()                        
		elif ESTRATEGIA_POSICIONAMENTO == 'MSU':
			simulador.EstrategiaMuMsu()                        
	
		print vetorReg
		n = len(vetorReg)
		for i in range(n):
			print "Ver: " +str(vetorReg[i]) + " " +str(topology.node[int(vetorReg[i])]['regenerador'])
		
		for e in xrange(int(ERLANG_MIN), int(ERLANG_MAX+1), int(ERLANG_INC)):
		#for aux in xrange(int(ERLANG_MIN), int(ERLANG_MAX+1), int(ERLANG_INC)):
			#e = aux*0.1                    #METODO UTILIZADO PARA SIMULACOES DE VALORES FRACIONADOS
			Bloqueio = []
			Bloqueio2 = []
			Simulador.Ver = 0
			Simulador.NumReqBlocked2 = 0
			Simulador.NumReqBlockedAux = 0
			Simulador.NumReqBlockedTempo = 0
			Simulador.NumReqBlockedRecurso = 0
			Simulador.NumReqAccept = 0
			VerSimultaneo  = 0

			#print "..Aux..: " +str(aux)
			#print "... E ... " +str(e)
			#print "... Holding Time: " +str(HOLDING_TIME)
			for rep in xrange(10):
				rate = e / HOLDING_TIME
				seed(RANDOM_SEED)
				SimPy.Simulation.initialize()
				simulador = Simulador()
				SimPy.Simulation.activate(simulador,simulador.Run(rate))
				SimPy.Simulation.simulate(until=MAX_TIME)#MAX_TIME

				BloqueioTotal2 = 0.0                            
				#print BloqueioTotal2

				BloqueioTotal = float(Simulador.NumReqBlocked) / float(NUM_OF_REQUESTS)
				Bloqueio.append(BloqueioTotal)

				BloqueioTotal2 = float(Simulador.NumReqBlocked2) / float(NUM_OF_REQUESTS)
				Bloqueio2.append(BloqueioTotal2)

				VerSimultaneo += Simulador.VerSimultaneo

				#print rate
				print "Erlang", e, "Simulacao...", rep, "Percentual..: " +str(BloqueioTotal2), "Qtd VER simultaneo..: " +str(Simulador.VerSimultaneo)
				 
				#n = len(vetorReg)
				#for i in range(n):
				#       print "Ver: " +str(vetorReg[i]) + " " +str(topology.node[int(vetorReg[i])]['regenerador'])
					
				#BloqueioTotal = float(Simulador.NumReqBlocked) / float(NUM_OF_REQUESTS)
				#Bloqueio.append(BloqueioTotal)
				# print "FINAL...: " +str(vetorVer)
				#n = len(vetorReg)
				#for i in range(n):
				#       print "Ver: " +str(vetorReg[i]) + " " +str(topology.node[int(vetorReg[i])]['regenerador'])

				#BloqueioTotal2 = 0.0
				#print BloqueioTotal2
				#print SLOTS
				
			print Bloqueio2                         
			TotalVer += Simulador.Ver
			result = CalculaMediaDesvio(Bloqueio2)
			media = Media(Bloqueio2)
			mediaVer = float(Simulador.NumReqAccept) / float(Simulador.Ver)
			arquivo1.write(str(e))                  # e = erlang
			arquivo1.write("\t")
			arquivo1.write(str(result[0]))
			arquivo1.write("\t")
			arquivo1.write(str(result[0]-1.96*result[1]/math.sqrt(len(Bloqueio2))))
			arquivo1.write("\t")
			arquivo1.write(str(result[0]+1.96*result[1]/math.sqrt(len(Bloqueio2))))
			arquivo1.write("\t")
			arquivo1.write(str(Simulador.Ver))              # quantidade total de VER utilizado
			arquivo1.write("\t")
			arquivo1.write(str(Simulador.NumReqAccept))     # numero total de requisições aceitas
			arquivo1.write("\t")
			arquivo1.write(str(Simulador.NumReqBlockedAux)) # numero total de requisições bloqueadas
			arquivo1.write("\t")
			arquivo1.write(str(Simulador.NumReqBlockedTempo)) # numero total de requisições bloqueadas por tempo do ddl estourado
			arquivo1.write("\t")
			arquivo1.write(str(Simulador.NumReqBlockedRecurso)) # numero total de requisições bloqueadas por falta de recurso			
			arquivo1.write("\t")
			arquivo1.write(str(mediaVer))                   # média das requisições aceitas / pela quantidade de VER utilizado
			arquivo1.write("\t")
			arquivo1.write(str(VerSimultaneo/10))           # média dos VER usado simultaneamente
			arquivo1.write("\t")
			arquivo1.write(str(Simulador.total_slotsFinal))    # total de slots economizados
			arquivo1.write("\t")			
			arquivo1.write(str(Bloqueio2))                  # média dos bloqueios em cada repetição
			arquivo1.write("\n")
			
		arquivo1.write(str(vetorReg))
		arquivo1.write("\n")                
		arquivo1.write(str(TotalVer))
		arquivo1.write("\n")
		
		print 'Regeneradores: ' + str(vetorReg)
		print 'N Requisicao: ' + str(simulador.NumReq)
		print 'Bloqueados: ' + str(simulador.NumReqBlocked)
		#print 'Lista de No: ' + str(simulador.ListReg)
		print 'Total Reg Usados: ' + str(TotalVer)
		#print 'Total Slots Inicial: ' + str(Simulador.total_slotsInicial)
		#print 'Total Slots Final  : ' + str(Simulador.total_slotsFinal)
		print 'Total Slots economizados  : ' + str(Simulador.total_slotsFinal)

		#n = len(vetorReg)
		#for i in range(n):
		#	print "Ver: " +str(vetorReg[i]) + " " +str(topology.node[int(vetorReg[i])]['regenerador'])
		
		
		arquivo1.close()
		return 0
	else:
		simulador = Simulador()
		
		# Estrategia de posicionamento
		if ESTRATEGIA_POSICIONAMENTO == 'NDF':
			#simulador.Ndf(QTD_REG)
			simulador.EstrategiaNdf()
		elif ESTRATEGIA_POSICIONAMENTO == 'LNDF':
			#simulador.Lndf(QTD_REG)
			simulador.EstrategiaLndf()
		elif ESTRATEGIA_POSICIONAMENTO == 'HNF':
			simulador.Hnf(1)
		elif ESTRATEGIA_POSICIONAMENTO == 'LHNF':
			simulador.Lhnf(1)                        
		elif ESTRATEGIA_POSICIONAMENTO == 'MU':
			simulador.EstrategiaMuMsu()
		elif ESTRATEGIA_POSICIONAMENTO == 'MSU':
			simulador.EstrategiaMuMsu()                        
		"""
		simulador = Simulador()
		simulador.EstrategiaLndf()
		"""
		#simulador.QuantidadeVer()
		print vetorReg
		vetorPath.sort()
		print vetorPath
		#print len(vetorPath)
		#simulador.EstrategiaLndf()
		#print 'teste'
	
if __name__ == '__main__':
	import sys
	sys.exit(main(sys.argv)
)
