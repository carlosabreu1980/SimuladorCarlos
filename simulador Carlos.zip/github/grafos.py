#!/usr/bin/env python
# -*- coding: utf-8 -*-

import SimPy
from SimPy import *
from SimPy.Simulation import *
from random import *
from grafos import *
from random import *

import networkx as nx
from random import randrange

# Monta a topologia na variavel g
g = nx.read_weighted_edgelist('nsfnet', nodetype=int)

# Variaveis globais
bloqueado = 0
nao_bloqueado = 0
no_regenerador = 0

# Restricao
parametro_dist = 2800
parametro_salto = 2

class Simulador(Process):       
        def  __init__(self):
                #print "entrou init"
                #SimPy.Simulation.Process.__init__(self)
                self.random = Random()

        # Adicionando regenerador ao vertice
        def add_regenerador(self, a):
                g.add_nodes_from([a],regenerador=1)
                regenerador=nx.get_node_attributes(g,'regenerador')
                return regenerador[a]

        # Validacao do caminho. Retorna se um certo caminho o - d e bloqueado ou nao
        def ValidarCaminho(self, graph, path): 
                global bloqueado
                global nao_bloqueado
                global g
                global parametro_dist
                global parametro_salto
                global no_regenerador

                soma  = 0       
                salto = 0       
                block = 1
                for i in range(0, (len(path)-1)):               
                        soma = soma + g[path[i]][path[i+1]]['weight']   #recebe peso da aresta entre i e i+1
                        salto= salto + 1                                        #incrementa o salto
                
                        if (soma > parametro_dist) or (salto > parametro_salto):                        
                                bloqueado = bloqueado + 1
                                return False
                                #block = 0
                                #return bloqueado        
                
                        try:
                                if (g.node[path[i+1]]['regenerador']) == (1):       #verifica se existe regenerador no proximo vertice              
                                        soma = 0                                                #se existe, zera os parametros e continua ate atingir o destino ou outro ponto de restauracao
                                        salto= 0
                        except Exception:
                                ""
                        
                #nao_bloqueado = nao_bloqueado + block
                #return nao_bloqueado
                return True

        def dfs_validar(self, inicio, fim):
                global g
                
                pilha = [(inicio, [inicio])]
                
                while pilha:
                        vertice, caminho = pilha.pop()
                        for proximo in set(g[vertice]) - set(caminho):
                                if proximo == fim:
                                        yield caminho + [proximo]
                                        #print "Caminho 1" + str(caminho)
                                        validar = self.ValidarCaminho(g, caminho)
                                        if (validar == True):
                                                print "bloqueado: " + str(caminho)
                                                
                                        else:
                                                print "Caminho nao block: " + str(caminho)
                                else:
                                        print "caminho final: " + str(caminho)
                                        pilha.append((proximo, caminho + [proximo]))

        def dfs(self, inicio, fim):
                pilha = [(inicio, [inicio])]
                while pilha:
                        vertice, caminho = pilha.pop()
                        for proximo in set(g[vertice]) - set(caminho):
                                if proximo == fim:
                                        yield caminho + [proximo]
                                else:
                                        pilha.append((proximo, caminho + [proximo]))
                

        # Posicionamento de Regeneradores
        def posicionamentoReg(self, a):
                if a == 1:
                        # NFSnet estrateegia L-NDF grau nodal + soma peso logico
                        self.add_regenerador(5)
                        self.add_regenerador(8)
                        self.add_regenerador(0)
                        self.add_regenerador(7)
                        self.add_regenerador(3)
                        self.add_regenerador(10)
                
                elif a == 2:
                        # NFSnet estrategia NDF grau nodal
                        #print "entrou estrategia"
                        self.add_regenerador(5)
                        self.add_regenerador(8)
                        self.add_regenerador(0)
                        self.add_regenerador(1)
                        self.add_regenerador(2)
                        self.add_regenerador(3)
                        self.add_regenerador(4)
                        self.add_regenerador(7)

                elif a == 3:
                        # NFSnet estrateegia HNF grau logico
                        self.add_regenerador(5)
                        self.add_regenerador(8)
                        self.add_regenerador(3)
                        self.add_regenerador(7)
                        self.add_regenerador(11)
                        self.add_regenerador(13)
                        self.add_regenerador(9)
                        self.add_regenerador(0)
                        self.add_regenerador(4)

        #def CaminhoValido(self, graph, path):
                
def main(args):
        
        simulador = Simulador()

        # Define a estrategia de posicionamento regeneradores
        simulador.posicionamentoReg(1)

        # Numero de requisicoes
        n = g.number_of_nodes()

        caminhos = list(simulador.dfs(0, 12))

        #i = 25
        
        #for i in range(0, (len(caminhos)-1)):
        for i in range(0, (len(caminhos)-1)):
        
                if (simulador.ValidarCaminho(g, caminhos[i]) == True):
                        print "Nao Bloqueado: " +str(caminhos[i])
        
        #list(simulador.dfs_validar(0, 12))
        
        
        """
        # Calcular o menor caminho origem - destino 
        for i in range(n):
                for j in range(n):
                        if i == j:
                                ""
                        else:
                                length,path=nx.bidirectional_dijkstra(g,i,j)
                                print(length, path) 
                                simulador.caminho(g, path)
                                print bloqueado
                                print "______________________________"                  

        # Impressao de resultados
        percentual = (float(bloqueado)/float(bloqueado+nao_bloqueado))*100
        print 'bloqueado    : ' + str(bloqueado)
        print 'nao bloqueado: ' + str(nao_bloqueado)
        print 'percentual   : ' + str(percentual)
        """
        
if __name__ == '__main__':
        import sys
        sys.exit(main(sys.argv))

